package com.alejandro.villasenor.currencyconverter.application;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CurrencyConverter {
    private double initialAmount;
    private double finalAmount;
    private double conversionRate;
    private String initialCurrencyCode;
    private String finalCurrencyCode;
    private String conversionTime;

    // Method to perform the conversion
    public CurrencyConverter performConversion(JsonObject exchangeRates, String fromCurrency, String toCurrency, double amount) {
        this.initialAmount = amount;
        this.conversionRate = Double.parseDouble(String.valueOf(exchangeRates.get(toCurrency)));
        this.initialCurrencyCode = fromCurrency;
        this.finalCurrencyCode = toCurrency;
        this.finalAmount = this.initialAmount * this.conversionRate;

        // Format the time of the conversion
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        this.conversionTime = LocalTime.now().format(timeFormatter);
        return this;
    }

    // Method to extract the currency code
    public String extractCurrencyCode(String currency) {
        try {
            String code;

            // Regular expression to extract the currency code inside parentheses
            Pattern pattern = Pattern.compile("\\((.*?)\\)");
            Matcher matcher = pattern.matcher(currency);

            if (matcher.find()) {
                code = matcher.group(1);
                return code;
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return "";
    }

    // Override toString method to display the conversion details
    @Override
    public String toString() {
        return String.format("Converted { %.2f %s to %.2f %s at %s }"
                , this.initialAmount
                , this.initialCurrencyCode
                , this.finalAmount
                , this.finalCurrencyCode
                , this.conversionTime);
    }
}

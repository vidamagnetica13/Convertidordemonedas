package com.alejandro.villasenor.currencyconverter.application;

public class JsonObject {

    public char[] get(String toCurrency) {
        
        throw new UnsupportedOperationException("Unimplemented method 'get'");
    }

}

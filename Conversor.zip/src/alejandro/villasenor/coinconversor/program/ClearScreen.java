package alejandro.villasenor.coinconversor.program;

import java.io.IOException;

public class ClearScreen {
    public void clear() {
        try {
            // For Linux or macOS, the command is 'clear'
            new ProcessBuilder("clear")
                    .inheritIO()
                    .start()
                    .waitFor();
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}

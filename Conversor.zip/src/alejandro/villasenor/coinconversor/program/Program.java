package alejandro.villasenor.coinconversor.program;

import alejandro.villasenor.coinconversor.queries.Queries;
import java.util.Scanner;

public class Program {

    // Constructor
    public Program() {
    }

    // Additional methods
    public void startProgram() {
        // Creating global variables within the loop
        boolean isRunning = true;
        Interface ui = new Interface();
        Scanner scanner = new Scanner(System.in);
        Queries queries = new Queries();
        
        while (isRunning) {
            try {
                System.out.println((ui.getMenu()));
                int option = Integer.parseInt(scanner.nextLine());

                switch (option) {
                    case 1:
                        queries.query("USD", "ARS"); // Dollar to Argentine Peso
                        break;
                    case 2:
                        queries.query("ARS", "USD"); // Argentine Peso to Dollar
                        break;
                    case 3:
                        queries.query("USD", "BRL"); // Dollar to Brazilian Real
                        break;
                    case 4:
                        queries.query("BRL", "USD"); // Brazilian Real to Dollar
                        break;
                    case 5:
                        queries.query("USD", "COP"); // Dollar to Colombian Peso
                        break;
                    case 6:
                        queries.query("COP", "USD"); // Colombian Peso to Dollar
                        break;
                    case 7:
                        queries.query("USD", "MXN"); // Dollar to Mexican Peso
                        break;
                    case 8:
                        queries.query("MXN", "USD"); // Mexican Peso to Dollar
                        break;
                    case 9:
                        queries.specificQuery(); // Specific conversion
                        break;
                    case 10:
                        queries.printHistory(); // View history
                        break;
                    case 11:
                        isRunning = false; // Exit
                        break;
                    default:
                        System.out.println("Error! Invalid option.");
                        break;
                }
            } catch (Exception e) {
                System.out.println("Error: '" + e.getMessage() + "'");
            } finally {
                if (isRunning) {
                    int retryCounter = 0;
                    boolean validResponse = false;
                    while (!validResponse) {
                        System.out.println("\nDo you want to perform another action? Y / N");
                        String response = scanner.nextLine();
                        if (response.equalsIgnoreCase("y") || response.equalsIgnoreCase("n")) {
                            if (response.equalsIgnoreCase("n")) {
                                isRunning = false;
                                System.out.println("Shutting down the program...");
                            }
                            validResponse = true;
                        }
                        if (retryCounter > 2) {
                            validResponse = true;
                            isRunning = false;
                        }
                        retryCounter++;
                    }
                } else {
                    System.out.println("Shutting down the program...");
                }
            }
        }
    }
}

package alejandro.villasenor.coinconversor.program;

import com.google.gson.JsonObject;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Converter {
    private double originalValue;
    private double finalValue;
    private double exchangeRate;
    private String initialCurrencyCode;
    private String finalCurrencyCode;
    private String currentTime;

    // Methods
    public Converter convert(JsonObject jsonCurrencies, String fromCurrency, String toCurrency, double amount) {
        this.originalValue = amount;
        this.exchangeRate = Double.parseDouble(String.valueOf(jsonCurrencies.get(toCurrency)));
        this.initialCurrencyCode = fromCurrency;
        this.finalCurrencyCode = toCurrency;
        this.finalValue = this.originalValue * this.exchangeRate;

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        this.currentTime = LocalTime.now().format(formatter);
        return this;
    }

    // Extractor method
    public String extract(String currency) {
        try {
            String code;

            // Programming the text extractor
            Pattern pattern = Pattern.compile("\\((.*?)\\)");
            Matcher matcher = pattern.matcher(currency);

            if (matcher.find()) {
                code = matcher.group(1);
                return code;
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return "";
    }

    @Override
    public String toString() {
        return String.format("Converted { %.2f %s to %.2f %s at %s }"
                , this.originalValue
                , this.initialCurrencyCode
                , this.finalValue
                , this.finalCurrencyCode
                , this.currentTime);
    }
}
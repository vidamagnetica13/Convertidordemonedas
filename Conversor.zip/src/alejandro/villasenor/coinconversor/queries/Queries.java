package alejandro.villasenor.coinconversor.queries;

import alejandro.villasenor.coinconversor.program.Converter;
import alejandro.villasenor.coinconversor.program.Interface;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.FileWriter;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Queries {
    private String apiKEY = "0016d4d4ba6a6208c6078e77";
    private String url;
    private List<Converter> history = new ArrayList<>();

    // Constructor
    public Queries() {
        this.url = "https://v6.exchangerate-api.com/v6/" + this.apiKEY + "/latest/";
    }

    // Additional methods

    // General query
    public void query(String initialCurrency, String targetCurrency) {
        try {
            // Create a scanner and a double variable that will hold the amount to convert
            Scanner scanner = new Scanner(System.in);
            double amountToConvert = 0;
            Converter convertedData = new Converter();

            // Create client, request, and response objects to perform the query
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(this.url + initialCurrency))
                    .build();
            HttpResponse<String> response = client
                    .send(request, HttpResponse.BodyHandlers.ofString());

            // Create a Gson object to generate the json file
            Gson gson = new Gson();
            String json = response.body();

            // Filter the file to get only the json that interests us
            ApiJsonObject jsonConversions = gson.fromJson(json, ApiJsonObject.class);

            /*
             * Send the ApiJsonObject which contains a json attribute with the information
             * we are interested in, along with the amount we want to convert and the
             * currency codes to the Conversor class to extract the relevant information
            */
            Converter conversor = new Converter();
            System.out.print("Enter the amount of " + initialCurrency + " you want to convert to " +
                    targetCurrency + ": ");
            amountToConvert = scanner.nextDouble();
            convertedData = conversor.convert(jsonConversions.conversion_rates(),
                    initialCurrency,
                    targetCurrency,
                    amountToConvert);
            System.out.println(convertedData);
            this.history.add(convertedData);
        } catch (Exception e) {
            System.out.println("Error!\n" + e.getMessage());
        }
    }

    // Specific query
    public void specificQuery() {
        Interface ui = new Interface();
        Converter converter = new Converter();
        Scanner scanner = new Scanner(System.in);

        List<String> availableCurrencies = ui.getAvailableCurrencies();
        for (int i = 0; i < availableCurrencies.size(); i++) {
            System.out.println((i + 1) + " - " + availableCurrencies.get(i));
        }

        System.out.println("Select the number of the currency you want to convert: ");
        int option1 = Integer.parseInt(scanner.nextLine());

        System.out.println("Select the number of the currency to convert into: ");
        int option2 = Integer.parseInt(scanner.nextLine());

        query(converter.extract(availableCurrencies.get(option1 - 1)),
              converter.extract(availableCurrencies.get(option2 - 1)));
    }

    public void printHistory() {
        if (!this.history.isEmpty()) {
            System.out.println("Conversion history: ");
            for (int i = 0; i < this.history.size(); i++) {
                System.out.println((i + 1) + " - " + this.history.get(i));
            }
            createHistoryDocument();
        } else {
            System.out.println("History is empty, no conversions have been made yet.");
        }
    }

    private void createHistoryDocument() {
        try {
            FileWriter writer = new FileWriter("Conversion-History.txt");

            for (int i = 0; i < history.size(); i++) {
                writer.write((i + 1) + " - " + history.get(i) + "\n");
            }
            writer.close();
        } catch (Exception e) {
            System.out.println("Error: '" + e.getMessage() + "'");
        }
    }
}

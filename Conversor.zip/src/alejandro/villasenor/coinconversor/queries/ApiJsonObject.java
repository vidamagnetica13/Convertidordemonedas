package alejandro.villasenor.coinconversor.queries;

import com.google.gson.JsonObject;

public record ApiJsonObject(JsonObject conversion_rates) {
}
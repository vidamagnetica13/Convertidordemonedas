import alejandro.villasenor.coinconversor.program.Program;

public class Main {
    public static void main(String[] args) {
        Program programa = new Program();
        programa.startProgram();
    }
}